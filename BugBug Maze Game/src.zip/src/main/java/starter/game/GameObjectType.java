package starter.game;

public enum GameObjectType {
  BUGBUG,
  LADYBUG,
  FOOD
}
