package starter.game;

public enum GameStatus {
  WON,
  LOST,
  ONGOING
}
