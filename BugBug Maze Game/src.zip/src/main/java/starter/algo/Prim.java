package starter.algo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Set;
import starter.model.Cell;
import starter.model.Grid;
import java.util.Objects;


public class Prim {

  public static Random RND = new Random(5);

  //private static Map<Cell, Integer> distances = new HashMap<>();
  private static Map<Cell, Integer> weights = new HashMap<>();
  private static Map<Cell, Cell> previous = new HashMap<>();
  private static Set<Cell> explored = new HashSet<>();
  //private static Queue<Cell> trail = new LinkedList<>();





  private static class CellWeightPair implements Comparable<CellWeightPair> {
    Cell cell;
    int weight;

    CellWeightPair(Cell cell, int weight) {
      this.cell = cell;
      this.weight = weight;
    }

    @Override
    public int compareTo(CellWeightPair other) {
      return (int) (Math.signum(this.weight - other.weight));
    }

    /*
    @Override
    public int hashCode() {
      return Objects.hash(weight);
    }
     */
  }


  public static void apply(Grid grid) {
    Cell s = grid.getCell();
    explored.add(s);
    PriorityQueue<CellWeightPair> pq3 = new PriorityQueue<>();
    //CellWeightPair cwp3 = new CellWeightPair(s, RND.nextInt(4) + 1);
    //pq3.add(cwp3);

    List<Cell> neighbors = new ArrayList<>();
    if (s.getNorth() != null) {
      neighbors.add(s.getNorth());
      CellWeightPair cwp4 = new CellWeightPair(s.getNorth(), RND.nextInt(4) + 1);
      pq3.add(cwp4);
    }
    if (s.getEast() != null) {
      neighbors.add(s.getEast());
      CellWeightPair cwp5 = new CellWeightPair(s.getEast(), RND.nextInt(4) + 1);
      pq3.add(cwp5);
    }

    if (s.getSouth() != null) {
      neighbors.add(s.getSouth());
      CellWeightPair cwp6 = new CellWeightPair(s.getSouth(), RND.nextInt(4) + 1);
      pq3.add(cwp6);
    }
    if (s.getWest() != null) {
      neighbors.add(s.getWest());
      CellWeightPair cwp7 = new CellWeightPair(s.getWest(), RND.nextInt(4) + 1);
      pq3.add(cwp7);
    }



    CellWeightPair cwp0 = pq3.peek();
    //pq3.add(cwp0);
    Cell s2 = cwp0.cell;
    //explored.add(s2);
    s.link(s2);


    /*
    if (neighbors.size() != 0) {
      int index = RND.nextInt(neighbors.size());
      s.link(neighbors.get(index));
    }
     */

    /*
    for (Cell cell : grid) {
      CellWeightPair cwp = new CellWeightPair(cell, RND.nextInt(4) + 1);
      pq.add(cwp);
    }
     */


    while (!pq3.isEmpty()) {
      CellWeightPair cwp = pq3.poll();
      Cell smallest = cwp.cell;
      if (explored.contains(smallest)) {
        continue;
      }
      explored.add(smallest);
      //smallest.link(smallest);

      List<Cell> neighbors4 = new ArrayList<>();
      if (smallest.getNorth() != null && !explored.contains(smallest.getNorth())) {
        neighbors4.add(smallest.getNorth());
        CellWeightPair cwp9 = new CellWeightPair(smallest.getNorth(), RND.nextInt(4) + 1);
        pq3.add(cwp9);
      }
      if (smallest.getEast() != null && !explored.contains(smallest.getEast())) {
        neighbors4.add(smallest.getEast());
        CellWeightPair cwp10 = new CellWeightPair(smallest.getEast(), RND.nextInt(4) + 1);
        pq3.add(cwp10);
      }
      if (smallest.getSouth() != null && !explored.contains(smallest.getSouth())) {
        neighbors4.add(smallest.getSouth());
        CellWeightPair cwp11 = new CellWeightPair(smallest.getSouth(), RND.nextInt(4) + 1);
        pq3.add(cwp11);
      }
      if (smallest.getWest() != null && !explored.contains(smallest.getWest())) {
        neighbors4.add(smallest.getWest());
        CellWeightPair cwp12 = new CellWeightPair(smallest.getWest(), RND.nextInt(4) + 1);
        pq3.add(cwp12);
      }

      CellWeightPair cwp15 = pq3.peek();

      //pq3.add(cwp0);
      Cell s5 = cwp15.cell;
      smallest.link(s5);


      /*
      if (neighbors4.size() != 0) {
        int index = RND.nextInt(neighbors.size());
        smallest.link(neighbors.get(index));
      }

       */

      //smallest.link(pq.poll().cell);
      /*
      for (Cell c : smallest.getLinks()) {
        CellWeightPair cwp2 = new CellWeightPair(c, RND.nextInt(4) + 1);
        pq3.add(cwp2);
      }

       */

    }


  }
}
